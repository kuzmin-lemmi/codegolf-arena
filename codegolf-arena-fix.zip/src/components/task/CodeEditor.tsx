// src/components/task/CodeEditor.tsx

'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { validateOneliner, calculateCodeLength, cn } from '@/lib/utils';
import { AlertCircle, Check } from 'lucide-react';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  maxLength?: number;
  minimal?: boolean;
}

export function CodeEditor({
  value,
  onChange,
  placeholder = 'sum(map(int, s.split()))',
  disabled = false,
  maxLength = 2000,
  minimal = false,
}: CodeEditorProps) {
  const [isFocused, setIsFocused] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  const validation = validateOneliner(value);
  const length = calculateCodeLength(value);

  // Автоматическая высота textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      // Минимум 5 строк (~120px), максимум 10 строк (~240px)
      const minHeight = 120;
      const maxHeight = 240;
      textareaRef.current.style.height = `${Math.min(Math.max(scrollHeight, minHeight), maxHeight)}px`;
    }
  }, [value]);

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      let newValue = e.target.value;
      
      // Блокируем переносы строк - заменяем на пробел
      if (newValue.includes('\n') || newValue.includes('\r')) {
        newValue = newValue.replace(/[\n\r]+/g, ' ');
      }
      
      onChange(newValue);
    },
    [onChange]
  );

  const handleKeyDown = useCallback((e: React.KeyboardEvent<HTMLElement>) => {
    // Блокируем Enter - не даём создать перенос строки
    if (e.key === 'Enter') {
      e.preventDefault();
    }
  }, []);

  const handlePaste = useCallback((e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    e.preventDefault();
    const text = e.clipboardData.getData('text');
    // Убираем переносы строк при вставке
    const cleanText = text.replace(/[\n\r]+/g, ' ');
    
    const textarea = e.currentTarget;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const newValue = value.slice(0, start) + cleanText + value.slice(end);
    
    onChange(newValue);
    
    // Устанавливаем курсор после вставленного текста
    setTimeout(() => {
      textarea.selectionStart = textarea.selectionEnd = start + cleanText.length;
    }, 0);
  }, [value, onChange]);

  // Minimal mode - for inline use in scaffold
  if (minimal) {
    return (
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        onPaste={(e) => {
          e.preventDefault();
          const text = e.clipboardData.getData('text').replace(/[\n\r]+/g, ' ');
          const start = e.currentTarget.selectionStart || 0;
          const end = e.currentTarget.selectionEnd || 0;
          onChange(value.slice(0, start) + text + value.slice(end));
        }}
        placeholder={placeholder}
        disabled={disabled}
        spellCheck={false}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="off"
        className={cn(
          'w-full px-3 py-3 bg-transparent resize-none',
          'text-[rgb(var(--code-inline-text))] placeholder:text-[rgb(var(--code-muted))]',
          'focus:outline-none focus:bg-[rgb(var(--code-bg))]',
          'transition-colors',
          disabled && 'cursor-not-allowed opacity-50'
        )}
        style={{
          fontFamily: "'JetBrains Mono', 'Fira Code', 'Consolas', 'Monaco', monospace",
          fontSize: '14px',
          fontWeight: 400,
        }}
      />
    );
  }

  return (
    <div className="space-y-3">
      {/* Editor Container - VS Code Dark+ Theme */}
      <div
        className={cn(
          'relative rounded-lg overflow-hidden transition-all duration-200',
          'bg-[rgb(var(--code-bg))] border border-[rgb(var(--code-border))]',
          isFocused
            ? 'border-[rgb(var(--code-focus))] ring-1 ring-[rgb(var(--code-focus))]/40'
            : 'hover:border-[rgb(var(--border-light))]',
          !validation.valid && value && 'border-accent-red',
          disabled && 'opacity-50 cursor-not-allowed'
        )}
      >
        {/* Line numbers gutter */}
        <div className="absolute left-0 top-0 bottom-0 w-12 bg-[rgb(var(--code-bg))] border-r border-[rgb(var(--code-border))] flex items-start justify-end pr-3 pt-4 select-none pointer-events-none">
          <span className="text-[rgb(var(--code-number))] text-sm font-mono">1</span>
        </div>
        
        {/* Code input area */}
        <textarea
          ref={textareaRef}
          value={value}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={placeholder}
          disabled={disabled}
          spellCheck={false}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          rows={5}
          className={cn(
            'w-full pl-14 pr-4 py-4 bg-transparent resize-none',
            'text-[rgb(var(--code-text))] placeholder:text-[rgb(var(--code-muted))]',
            'focus:outline-none',
            'overflow-x-auto whitespace-pre',
            disabled && 'cursor-not-allowed'
          )}
          style={{
            fontFamily: "'JetBrains Mono', 'Fira Code', 'Consolas', 'Monaco', monospace",
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '1.6',
            tabSize: 4,
            minHeight: '120px',
          }}
        />
      </div>

      {/* Status bar - VS Code style */}
      <div className="flex items-center justify-between px-1">
        {/* Validation status */}
        <div className="flex items-center gap-2 text-sm">
          {value ? (
            validation.valid ? (
              <span className="flex items-center gap-1.5 text-accent-green">
                <Check className="w-4 h-4" />
                <span>OK</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-accent-red">
                <AlertCircle className="w-4 h-4" />
                <span>{validation.error}</span>
              </span>
            )
          ) : (
            <span className="text-[rgb(var(--code-muted))]">Введите однострочник</span>
          )}
        </div>

        {/* Length counter */}
        <div
          className={cn(
            'flex items-center gap-2 text-sm font-mono',
            length > maxLength ? 'text-accent-red' : 'text-[rgb(var(--code-number))]'
          )}
        >
          <span>Длина:</span>
          <span className={cn(
            'font-bold px-2 py-0.5 rounded',
            length > 0 ? 'bg-[rgb(var(--code-line))] text-[rgb(var(--code-accent))]' : ''
          )}>
            {length}
          </span>
          {length > maxLength && <span className="text-accent-red">/ {maxLength}</span>}
        </div>
      </div>

      {/* Hint */}
      <p className="text-xs text-[rgb(var(--code-muted))] px-1">
        💡 Пробелы внутри кода учитываются в длине. Enter заблокирован — код должен быть в одну строку.
      </p>
    </div>
  );
}

// Экспорт для совместимости
export function MonacoCodeEditor(props: CodeEditorProps) {
  return <CodeEditor {...props} />;
}
